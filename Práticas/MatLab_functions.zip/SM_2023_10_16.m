N=1000;           % number of samples
Ta=0.001;         % sampling period
fa=1/Ta;          % sampling frequency
fo=20;            % signal frequency
t=(0:N-1)*Ta;     % time instants
x=sin(2*pi*fo*t); % signal
X=fft(x)/N;       % DFT
f=(0:N-1)/N*fa;   % DFT frequencies
fh=figure(1);     % get figure handle
plot(f,abs(X));   % graph abs(DFT)
grid on;
fh.PaperType='A4';
fh.PaperOrientation='landscape';
print('DFT.pdf','-dpdf','-noui','-fillpage');
