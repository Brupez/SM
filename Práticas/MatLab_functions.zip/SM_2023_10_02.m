%%
% parte 1 --- sinal normalizado
N=200;                 % número de amostras
f=0.1;                 % frequência relativa (f/fs)
x=cos(2*pi*f*(0:N-1)); % co-seno
fh=figure(1);
subplot(2,1,1);
plot(0:N-1,x,'o-');
grid on
zoom on
title('O sinal (eixo dos x em número de amostras)');
subplot(2,1,2);
plot((0:N-1)/N,abs(fft(x)/N),'o-');
grid on
zoom on
title('O valor absoluto da sua DFT (eixo dos x em frequência normalizada)');
if 0
  % para geral um PDF (para ficarem a saber como é que se faz...)
  fh.PaperType='A4';
  fh.PaperOrientation='landscape';
  fh.PaperUnits='points';
  print('figura1.pdf','-dpdf','-noui','-fillpage');
end

%%
% parte 2 --- sinal não normalizado
f=10;            % 10 Hz
na=10;           % número de amostras por período (experimente com um número não inteiro...)
fs=na*f;         % frequência de amostragem
np=4;            % número de períodos (experimente com um número não inteiro)
N=round(np*na);  % número de amostras
t=(0:N-1)/fs;    % instantes de tempo
x=cos(2*pi*f*t); % o sinal
figure(2);
subplot(2,1,1);
plot(t,x,'o-');
grid on
zoom on
title('O sinal (eixo dos x em segundos)');
subplot(2,1,2);
plot((0:N-1)/N*fs,abs(fft(x)/N),'o-');
grid on
zoom on
title('O valor absoluto da sua DFT (eixo dos x em Hz)');
