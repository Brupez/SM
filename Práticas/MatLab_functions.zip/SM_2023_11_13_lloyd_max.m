%
% Tomás Oliveira e Silva, November 2023
%
% Lloyd/Max algorithm (optimal quantization) examples
%
% [q,p] = SM_2023_11_13_lloyd_max(n,distribution,show)
%   outputs:
%     q are the quantization levels
%     p are the respective probabilities of occurrence
%   inputs:
%     n is the number of desired quantization values (at least 2 and at most 40)
%     distribution is one of
%       'uniform' .................. for an uniform distribution
%       'triangular' ............... for a triangular distribution
%       'exponential' .............. for an exponential distribution
%       'laplace' or 'laplacian' ... for a laplacian distribution
%       'normal' or 'gaussian' ..... for a normal distribution
%     show controls the graphs that are displayed; bitwise or of
%       1 ... evolution of the quantization values
%       2 ... evolution of the algorithm step size
%       4 ... curiosity (roots of the polynomial constructed from the quantization values)
%
function [q,p] = SM_2023_11_20_lloyd_max(n,distribution,show)
  % deal with a missing or bad first argument
  if nargin < 1
    n = 4; % default: 4 quantization values
  end
  n = max(2,min(40,round(n)));
  % deal with a missing or bad second argument
  if nargin < 2
    distribution = 'uniform'; % default: uniform distribution
  end
  switch distribution
    case 'uniform'
      d = 0; % mean=0, var=1/3
    case 'triangular'
      d = 1; % mean=0, var=1/6
    case 'exponential'
      d = 2; % mean=1, var=1
    case {'laplace','laplacian'}
      d = 3; % mean=0, var=2
    case {'normal','gaussian'}
      d = 4; % mean=0, var=1
    otherwise
      error('bad distribution');
  end
  % deal with a missing or bad third argument
  if nargin < 3
    show = 3; % default: show the first two figures
  end
  show = max(0,min(15,round(show)));
  % choose the initial subdivision points (with two fixed endpoints)
  x = zeros(1,n+1);
  switch d                % first, the fixed endpoints
    case 0 % uniform
      x(1) = -1;
      x(n+1) = 1;
    case 1 % triangular
      x(1) = -1;
      x(n+1) = 1;
    case 2 % exponential
      x(1) = 0;
      x(n+1) = 50;        % a replacement of +infinity
    case 3 % laplacian
      x(1) = -50;         % a replacement of -infinity
      x(n+1) = 50;        % a replacement of +infinity
    case 4 % normal
      x(1) = -10;         % a replacement of -infinity
      x(n+1) = 10;        % a replacement of +infinity
  end
  for i=2:n               % next, the other subdivision points (equiprobable quantization areas)
    y1 = (i-1)/n;         % desired cdf value
    x0 = x(1);
    x2 = x(n+1);
    while x2-x0 > 1.0e-10 % bissection method
      x1 = 0.5*(x0+x2);
      if cdf(x1,d) < y1
        x0 = x1;
      else
        x2 = x1;
      end
    end
    x(i) = 0.5*(x0+x2);
  end
  if 1 % perturb t (do NOT use a perturbation factor larger than 1)
    xx = x;
    for i=2:n
      x(i) = x(i)+0.8*(rand-0.5)*min(xx(i)-xx(i-1),xx(i+1)-xx(i));
    end
  end
  % iterate using lloyd's algorithm (using a quadratic distortion function)
  ni = 0;         % iteration number
  q = zeros(0,n); % the history of the quantization values
  e = [];         % convergence information
  goal = -10.5;   % precision goal (base-10 logarithm); do not use less than -10.5 (numerical precision issues)
  ng = 0;         % number of consecutive times the precision goal has been attained
  h = waitbar(0,sprintf('Progress (%s)',distribution));
  while 1
    ni = ni+1;
    % compute the optimal quantization values for the current subdivision points
    for i=1:n
      q(ni,i) = (xcdf(x(i+1),d)-xcdf(x(i),d))/(cdf(x(i+1),d)-cdf(x(i),d));
    end
    % force a symmetric solution (when appropriate)
    if d ~= 2
      q(ni,:) = (q(ni,:)-q(ni,end:-1:1))/2;
    end
    % compute the optimal subdivision points for the current quantization values
    xx = x;
    x(2:n) = 0.5*(q(ni,1:n-1)+q(ni,2:n));
    % compute the current precision estimate and update some loop-control variables
    e(ni) = log10(1.0e-20+max(abs(x-xx)));
    if e(ni) < goal
      ng = ng+1;
      if ng > 3
        break
      end
    else
      ng = 0;
    end
    % progress report
    waitbar(min(1,e(ni)/goal),h);
  end
  close(h);
  % show graphs
  scr = get(0,'ScreenSize');
  if bitand(show,1) ~= 0
    % quantization values history
    fig1 = figure(1);
    set(fig1,'Position',[scr(1)+100,scr(2)+10,scr(3)-200,scr(4)-180]);
    subplot('Position',[0.02,0.05,0.88,0.90]);
    plot(q,'.-');
    m1 = 0.1*floor(10*min(min(q))-0.01);
    m2 = 0.1*ceil(10*max(max(q))+0.01);
    axis([1,ni,m1,m2]);
    for i=1:n
      text(ni,q(ni,i),sprintf(' %+.6f (%8.6f)',q(ni,i),cdf(q(ni,i),d)),...
           'FontName','Courier','FontWeight','bold','VerticalAlignment','middle');
    end
    title(sprintf('Optimal %d quantization values for a %s distribution --- q (cdf(q))',n,distribution));
    grid on;
    zoom on;
  end
  if bitand(show,2) ~= 0
    % step size history
    fig2 = figure(2);
    set(fig2,'Position',[scr(1)+120,scr(2)+30,scr(3)-200,scr(4)-180]);
    subplot('Position',[0.02,0.05,0.88,0.90]);
    plot(e);
    title('base-10 logarithm of the step size');
    grid on;
    zoom on;
  end
  if bitand(show,4) ~= 0
    % curiosity (TO DO: this most definitely requires a theoretical explanation!)
    fig3 = figure(3);
    set(fig3,'Position',[scr(1)+140,scr(2)+50,scr(3)-200,scr(4)-180]);
    subplot('Position',[0.02,0.05,0.88,0.90]);
    r = roots(q(end,:))';
    [~,i] = sort(angle(r));
    r = r(i);
    r = [r,r(1)]; % to close the line drawing
    x0 = real(r);
    y0 = imag(r);
    x1 = cos(2*pi*(0:10000)/10000);
    y1 = sin(2*pi*(0:10000)/10000);
    xmin = min(-1.1,0.1*round(10*min(x0))-0.1);
    xmax = max(1.1,0.1*round(10*max(x0))+0.1);
    ymin = min(-1.1,0.1*round(10*min(y0))-0.1);
    ymax = max(1.1,0.1*round(10*max(y0))+0.1);
    plot(x1,y1,'b',x0,y0,'ko-');
    for i=1:n-1
      text(xmax,ymin+(ymax-ymin)*(2*i-1)/(2*n-2),sprintf(' %+.6f (%.6f)',angle(r(i))/(2*pi),abs(r(i))),...
           'FontName','Courier','FontWeight','bold','VerticalAlignment','middle');
    end
    axis('equal');
    axis([xmin,xmax,ymin,ymax]);
    title('roots of the polynomial constructed from the quantization values --- angle (modulus)');
    grid on
    zoom on
  end
  % set the output variables
  q = q(end,:);
  p = zeros(1,n);
  for i=1:n
    p(i) = cdf(x(i+1),d)-cdf(x(i),d);
  end


%
% probability density function
%
function y = pdf(x,d)
  switch d
    case 0 % uniform
      if x < -1
        y = 0.0;
      elseif x > 1
        y = 0.0;
      else
        y = 0.5;
      end
    case 1 % triangular
      if x < -1
        y = 0.0;
      elseif x > 1
        y = 0.0;
      else
        y = 1-abs(x);
      end
    case 2 % exponential
      if x < 0
        y = 0;
      else
        y = exp(-x);
      end
    case 3 % laplacian
      y = 0.5*exp(-abs(x));
    case 4 % normal
      y = exp(-0.5*x*x)/sqrt(2*pi);
  end

%
% cumulative distribution function (integral of pdf(x,d) between -infinity and x)
%
function y = cdf(x,d)
  switch d
    case 0 % uniform
      if x < -1
        y = 0.0;
      elseif x > 1
        y = 1.0;
      else
        y = 0.5*(x+1);
      end
    case 1 % triangular
      if x < -1
        y = 0.0;
      elseif x > 1
        y = 1.0;
      else
        y = 0.5+x-0.5*x*x*sign(x);
      end
    case 2 % exponential
      if x < 0
        y = 0;
      else
        y = 1-exp(-x);
      end
    case 3 % laplacian
      if x < 0
        y = 0.5*exp(x);
      else
        y = 1-0.5*exp(-x);
      end
    case 4 % normal
      y = 0.5+0.5*erf(x/sqrt(2));
  end

%
% integral of x*pdf(x,d) between -infinity and x
%
function y = xcdf(x,d)
  switch d
    case 0 % uniform
      if x < -1
        y = 0.0;
      elseif x > 1
        y = 0.0;
      else
        y = 0.25*(x*x-1);
      end
    case 1 % triangular
      if x < -1
        y = 0.0;
      elseif x > 1
        y = 0.0;
      else
        y = -sign(x)*x^3/3+0.5*x*x-1/6;
      end
    case 2 % exponential
      if x < 0
        y = 0;
      else
        y = 1-(1+x)*exp(-x);
      end
    case 3 % laplacian
      if x < 0
        y = -0.5*(1-x)*exp(x);
      else
        y = -0.5*(1+x)*exp(-x);
      end
    case 4 % normal
      y = -exp(-x^2/2)/sqrt(2*pi);
  end
