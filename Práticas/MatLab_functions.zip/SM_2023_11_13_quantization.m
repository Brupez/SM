clear all
close all
clc
% signals
t=(0:20000)/10000;
x=sin(2*pi*t);
delta=0.2;
q=round(x/delta);
xr=delta*q;
e=xr-x;
% figure
fig=figure('units','normalized','outerposition',[0.05,0.05,0.90,0.90]);
figure(1);
subplot('Position',[0.05,0.55,0.90,0.40]);
plot(t,x,'b',t,xr,'r',t,e,'k');
grid on;
legend('original','reconstruído','erro');
title('quantização e reconstrução');
subplot('Position',[0.05,0.05,0.90,0.40]);
hist(e,100)
grid on;
title('Histograma dos erros de quantização');
% print
if 0
  fig.PaperType='A4';
  fig.PaperOrientation='landscape';
  fig.PaperUnits='points';
  print('quantization.pdf','-dpdf','-noui','-fillpage');
end
