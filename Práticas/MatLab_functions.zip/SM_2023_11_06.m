clear all; close all; clc;
% https://www.101soundboards.com/boards/
%         10634-r2-d2-sounds-star-wars
[x,fs]=audioread('22.mp3');
sound(x,fs);
fig=figure(1);
subplot('Position',[0.10 0.10 0.85 0.85]);
spectrogram(x,hanning(1024),64,1024,fs,'yaxis');
fig.PaperType='A4';
fig.PaperOrientation='landscape';
fig.PaperUnits='points';
print('spectrogram.pdf','-dpdf','-noui','-fillpage');
