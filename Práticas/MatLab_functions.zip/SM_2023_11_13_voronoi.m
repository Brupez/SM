%
% Tomás Oliveira e Silva
%
% animation of a Voronoi diagram
%

clear all
close all
clc

n=20; % number of points
x=0.05+0.90*rand(1,n); % x coordinates
y=0.05+0.90*rand(1,n); % y coordinates
dx=0.01*rand(1,n)-0.005; % x velocity
dy=0.01*rand(1,n)-0.005; % y velocity

% animation
fig=figure('units','normalized','outerposition',[0.05,0.05,0.90,0.90]);
subplot('Position',[0.05,0.05,0.90,0.90]);
labels=arrayfun(@(idx){sprintf('P%02d',idx)},(1:n)');
for iter=0:100
  dt=tic;
  % draw
  voronoi(x,y);
  text(x,y,labels,'HorizontalAlignment','center','VerticalAlignment','middle');
  axis([0,1,0,1]);
  %axis('equal');
  grid on;
  title(sprintf('simulation step %d',iter));
  drawnow
  % update x coordinate
  x=x+dx;
  idx=find(x>0.95 | x<0.05);
  dx(idx)=-dx(idx);  % reflect
  x(idx)=x(idx)+dx(idx);
  % update y coordinate
  y=y+dy;
  idx=find(y>0.95 | y<0.05);
  dy(idx)=-dy(idx); % reflect
  y(idx)=y(idx)+dy(idx);
  % wait
  dt=toc(tic);
  pause(min(0.01,0.1-dt));
end
% optionally generate a PDF file of the final figure
if 0
  title('Example of a Voronoi diagram');
  fig.PaperType='A4';
  fig.PaperOrientation='landscape';
  fig.PaperUnits='points';
  print('voronoi.pdf','-dpdf','-noui','-fillpage');
end
