% this example requires the econometrics toolbox
%   (for the Markov chain functions)
clear all
close all
clc
format compact
format long

% create the Markov chain
mc=dtmc([0.7,0.2,0.1;0.4,0.5,0.1;0.2,0.6,0.2])

% stationary distribution
p=asymptotics(mc)

% display the markov chain
figure(1);
graphplot(mc,'LabelEdges',true);

% the Huffman code when in the first state
[hc1,len1]=huffmandict(1:3,mc.P(1,:))

% the Huffman code when in the second state
[hc2,len2]=huffmandict(1:3,mc.P(2,:))

% the Huffman code when in the third state
[hc3,len3]=huffmandict(1:3,mc.P(3,:))

% the overall average length
len=p(1)*len1+p(2)*len2+p(3)*len3
