for v=0.1:0.1:1
  for a=0:10:359
    [r,g,b]=hsv2rgb([a/360,1.0,v])
    plot(v*cos(pi*a/180),v*sin(pi*a/180),...
         'o','MarkerSize',3+7*v,...
         'MarkerFaceColor',[r,g,b],...
         'MarkerEdgeColor',[r,g,b]);
    hold on;
 end
end
hold off;
grid on;
axis([-1.1,1.1,-1.1,1.1]);
axis('equal');