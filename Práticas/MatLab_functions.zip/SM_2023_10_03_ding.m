fa=16000;                     % sampling frequency
t=(0:round(1.2*fa)-1)/fa;     % 1.2 seconds
x=sin(2*pi*782*t).*exp(-4*t); % 782Hz, exponential decay
audiowrite('ding.waw',x,fa);  % make .wav file
