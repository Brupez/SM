% clean environment
clear all
close all
clc
% read audio signal and extract first channel
[x,fs]=audioread('SM_2023_10_03_ding_dong.mp2');
x=x(:,1);
n=length(x);
% data for the FFTs
N=65536; % we use a large number of samples here
f=(0:N-1)/N*fs;
% compute envelope
y=0*x;
for i=2:n
  y(i)=max(abs(x(i)),0.9995*y(i-1)); % 0.9995 found by trial and error
end
% segment signal
idx=find(y>0.01); % 0.01 found by trial and error
brk=find(idx(2:end)-idx(1:end-1)>1);
if length(brk)~=1
  error('unexpected number of segments');
end
range1=idx(1:brk);
range2=idx(brk+1:end);
% show absolute value of the original time-domain signal with envelope
figure(1);
plot(1:n,abs(x),'r',1:n,y,'k',...
     range1,-0.05*ones(length(range1),1),'m',...
     range2,-0.05*ones(length(range2),1),'m');
grid on
zoom on
title('absolute value of the original sound (red) and its envelope (black)');
% analyze first sound
X1=abs(fft(x(range1),N));
[~,idx]=max(X1(1:N/2));
figure(2)
subplot(2,1,1);
plot(range1,abs(x(range1)),'r',range1,y(range1),'k');
grid on
zoom on
title('absolute value of the original sound (red) and its envelope (black)');
subplot(2,1,2);
plot(f,X1,'r',f(idx),X1(idx),'xk');
grid on
zoom on
title(sprintf('DFT of the sound (freq=%.2f [%.2f])',f(idx),12*log2(f(idx)/440)));
% analyze second sound
X2=abs(fft(x(range2),N));
[~,idx]=max(X2(1:N/2));
figure(3)
subplot(2,1,1);
plot(range2,abs(x(range2)),'r',range2,y(range2),'k');
grid on
zoom on
title('absolute value of the original sound (red) and its envelope (black)');
subplot(2,1,2);
plot(f,X2,'r',f(idx),X2(idx),'xk');
grid on
zoom on
title(sprintf('DFT of the sound (freq=%.2f [%.2f])',f(idx),12*log2(f(idx)/440)));
